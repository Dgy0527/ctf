"""patchboard —— Lab B3 的補丁台（形式照 lab-b2：攻破／修補雙計數）。

三個洞、三條 flag，各自一個計數：
  jwt         alg=none：自己簽一張 role=admin 的票 → /admin/panel 的身分區（flag1）
  massassign  PATCH /api/profile 把 role 寫進 DB  → /admin/panel 的帳號區（flag2）
  ssrf        /fetch?url= 沒有白名單            → 內網 admin 的 /flag（flag3）

每 120 秒換一次：flag1／flag2 寫進 memo 的 /srv，flag3 寫進 admin 的 /srv；
admin 帳號的密碼也一起換（學生永遠不知道它，只能靠洞變成 admin）。

補丁 = 上傳 handlers.py（只寫在 memo 的程式碼目錄內），服務自己偵測 mtime 重載。
"""
import base64
import hashlib
import html
import json
import os
import secrets
import sqlite3
import threading
import time
from urllib.parse import quote

import requests
from flask import Flask, redirect, request

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 256 * 1024      # 上傳上限 256KB（超過回 413）

ROUND = int(os.environ.get("ROUND_SECONDS", "120"))
MEMO = os.environ.get("MEMO", "http://memo:8000").rstrip("/")
MEMO_CODE = os.environ.get("MEMO_CODE", "/data/memo/app")
MEMO_DATA = os.environ.get("MEMO_DATA", "/data/memo/srv")
MEMO_DB = os.environ.get("MEMO_DB", "/data/memo/srv/memo.db")
ADMIN_DATA = os.environ.get("ADMIN_DATA", "/data/admin/srv")

DEMO = ("demo", "demo")

CHALLENGES = {
    "jwt": "JWT alg=none：自己簽一張 admin 的票",
    "massassign": "Mass assignment：把自己的 role 改成 admin",
    "ssrf": "SSRF：讓 memo 去打內網 admin",
    "misconfig": "A05：備份檔與 .git 忘了刪（沒有 flag，只有修補）",
}

# 只有這三個洞有 flag；misconfig 是「看得到就要收掉」的設定問題，不發 flag
FLAGGED = ("jwt", "massassign", "ssrf")

LOCK = threading.Lock()
STATE = {
    "flags": {},           # challenge -> 本輪 flag
    "attack": {k: 0 for k in CHALLENGES},
    "repair": {k: 0 for k in CHALLENGES},
    "claimed": [],         # 本輪已計分的 challenge
    "checks": {},          # 最近一次 apply 的三組 checks
    "logs": [],
}


def log(evt, detail=""):
    STATE["logs"].insert(0, {"t": time.strftime("%H:%M:%S"), "evt": evt, "detail": detail})
    del STATE["logs"][40:]


def sha(username, password):
    return hashlib.sha256(f"{username}:{password}".encode()).hexdigest()


def get(url, **kw):
    try:
        return requests.get(url, timeout=4, **kw)
    except requests.RequestException:
        return None


def write_flag(path, value):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        f.write(value + "\n")


# ---------------------------------------------------------------- 換 flag
def plant():
    for _ in range(90):
        if os.path.exists(MEMO_DB):
            break
        time.sleep(1)

    flags = {k: "flag{%s}" % secrets.token_hex(10) for k in FLAGGED}
    write_flag(os.path.join(MEMO_DATA, "flag1.txt"), flags["jwt"])
    write_flag(os.path.join(MEMO_DATA, "flag2.txt"), flags["massassign"])
    write_flag(os.path.join(ADMIN_DATA, "flag3.txt"), flags["ssrf"])

    # admin 的密碼換掉（學生不知道，只能靠洞拿到 admin）；順便把 demo 的 role 復位
    try:
        conn = sqlite3.connect(MEMO_DB, timeout=15)
        conn.execute("UPDATE users SET password=? WHERE username='admin'",
                     (sha("admin", secrets.token_hex(16)),))
        conn.execute("UPDATE users SET role='user' WHERE username='demo'")
        conn.commit()
        conn.close()
    except sqlite3.Error as exc:
        log("換 flag 時 DB 出錯", str(exc))

    with LOCK:
        STATE["flags"] = flags
        STATE["claimed"] = []
    log("換 flag", "三條都換了，admin 密碼也換了")


def rotate():
    first = True
    while True:
        if not first:
            time.sleep(ROUND)
        first = False
        try:
            plant()
        except Exception as exc:
            log("換 flag 失敗", str(exc))


# ---------------------------------------------------------------- checks
def login(username, password):
    s = requests.Session()
    try:
        r = s.post(MEMO + "/login", data={"username": username, "password": password},
                   timeout=5, allow_redirects=False)
    except requests.RequestException:
        return s, None
    return s, r


def func_checks():
    """三項功能：health、demo/demo 登入、GET /memo/1（SSRF 那組另外加 fetch 正常）。"""
    out = []
    r = get(MEMO + "/health")
    out.append(("health", r is not None and r.status_code == 200 and r.text.strip() == "ok"))
    s, r = login(*DEMO)
    out.append(("登入 demo/demo", r is not None and r.status_code in (301, 302, 303)))
    r = s.get(MEMO + "/memo/1", timeout=5)
    out.append(("GET /memo/1 回 200", r is not None and r.status_code == 200))
    return out, s


def _b64e(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode().rstrip("=")


def forge_none(claims):
    """洞 1 的利用方式：header 寫 alg=none、簽章留空。"""
    head = _b64e(json.dumps({"alg": "none", "typ": "JWT"}).encode())
    body = _b64e(json.dumps(claims).encode())
    return f"{head}.{body}."


def check_jwt(flag):
    out, s_demo = func_checks()
    # 功能：demo 自己看管理台要 200（不能靠把端點刪掉來「修好」）
    r = s_demo.get(MEMO + "/admin/panel", timeout=5)
    out.append(("demo 自己看 /admin/panel 回 200", r is not None and r.status_code == 200))
    token = forge_none({"sub": "demo", "role": "admin"})
    r = get(MEMO + "/admin/panel", headers={"Authorization": "Bearer " + token})
    leaked = bool(flag and r is not None and flag in r.text)
    out.append(("alg=none 的票進不去（JWT 已封）", not leaked))
    return out


def check_massassign(flag):
    out, s = func_checks()
    # 先把 demo 的 role 歸零，這一項才測得準（上一輪可能被改過）
    try:
        conn = sqlite3.connect(MEMO_DB, timeout=10)
        conn.execute("UPDATE users SET role='user' WHERE username='demo'")
        conn.commit()
        conn.close()
    except sqlite3.Error:
        pass
    # 功能：PATCH bio 要成功，而且不能順手把 role 改掉（不能靠刪掉 PATCH 來「修好」）
    bio_ok = False
    try:
        r = s.patch(MEMO + "/api/profile", json={"bio": "驗證用"}, timeout=5)
        bio_ok = r is not None and r.status_code == 200 and (r.json() or {}).get("role") == "user"
    except (requests.RequestException, ValueError):
        bio_ok = False
    out.append(("PATCH bio 正常、role 不變", bio_ok))

    try:
        s.patch(MEMO + "/api/profile", json={"role": "admin", "bio": "pwned"}, timeout=5)
    except requests.RequestException:
        pass
    r = s.get(MEMO + "/admin/panel", timeout=5)
    leaked = bool(flag and r is not None and flag in r.text)
    out.append(("自己的 role 改不掉（mass assignment 已封）", not leaked))
    try:
        s.patch(MEMO + "/api/profile", json={"role": "user", "bio": "實習生，負責備忘錄。"}, timeout=5)
    except requests.RequestException:
        pass
    return out


def check_ssrf(flag):
    out, _ = func_checks()
    r = get(MEMO + "/fetch", params={"url": "http://admin:8000/ping"})
    out.append(("fetch 正常（admin:8000/ping 回 pong）",
                r is not None and r.status_code == 200 and "pong" in r.text))
    r = get(MEMO + "/fetch", params={"url": "http://admin:8000/flag"})
    leaked = bool(flag and r is not None and flag in r.text)
    out.append(("內部 URL 被擋（SSRF 已封）", not leaked))
    return out


def check_misconfig(_flag=""):
    """A05：那些「忘了刪」的東西，修好之後應該回 404；三個功能照常。"""
    out, _ = func_checks()
    for name, path in (("備份檔 /app.py.bak 已刪（404）", "/app.py.bak"),
                       (".git 設定 /.git/config 已刪（404）", "/.git/config")):
        r = get(MEMO + path)
        out.append((name, r is not None and r.status_code == 404))
    return out


CHECKS = {"jwt": check_jwt, "massassign": check_massassign,
          "ssrf": check_ssrf, "misconfig": check_misconfig}


def wait_reload(want, tries=20):
    """等到 memo 真的載入新版 handlers.py；回傳載入錯誤（沒有就空字串）。"""
    for _ in range(tries):
        r = get(MEMO + "/_version")
        if r is not None and r.status_code == 200:
            try:
                info = r.json()
            except ValueError:
                info = {}
            if info.get("error"):
                return str(info["error"])
            if float(info.get("loaded") or 0) >= want - 0.001:
                return ""
        time.sleep(0.3)
    r = get(MEMO + "/_version")
    try:
        return str((r.json() or {}).get("error", "")) if r is not None else ""
    except ValueError:
        return ""


def run_checks():
    flags = dict(STATE["flags"])
    result = {}
    for key, fn in CHECKS.items():
        try:
            result[key] = fn(flags.get(key, ""))
        except Exception as exc:
            result[key] = [(f"{key} checks", False), ("error", False)]
            log("checks 出錯", f"{key}: {exc}")
    with LOCK:
        STATE["checks"] = result
    return result


# ---------------------------------------------------------------- 路由
@app.post("/submit")
def submit():
    ch = request.form.get("challenge", "")
    flag = (request.form.get("flag") or "").strip()
    if ch not in FLAGGED:
        return redirect("/?msg=" + quote("這個洞沒有 flag，只要修好就會加分"))
    with LOCK:
        ok = bool(flag) and ch in STATE["flags"] and flag == STATE["flags"].get(ch)
        if ok and ch in STATE["claimed"]:
            msg = "✗ 這條本輪已經算過了，等下一次換 flag"
        elif ok:
            STATE["claimed"].append(ch)
            STATE["attack"][ch] += 1
            msg = f"✓ 正確，{ch} 攻破 +1"
            log("攻破 +1", ch)
        else:
            msg = "✗ 不對或已過期（flag 每 %d 秒換一次）" % ROUND
    return redirect("/?msg=" + quote(msg))


@app.post("/apply")
def apply_patch():
    ch = request.form.get("challenge", "")
    target = (request.form.get("target") or "handlers.py").strip().lstrip("/")
    up = request.files.get("file")
    if ch not in CHALLENGES:
        return "challenge 不在名單內", 400
    if target != "handlers.py":            # 只收這一個檔名，其他一律拒絕
        return "target 只接受 handlers.py", 400
    if not up or not up.filename:
        return "沒有檔案", 400

    dest = os.path.join(MEMO_CODE, "handlers.py")
    os.makedirs(MEMO_CODE, exist_ok=True)
    up.save(dest)
    # 有些 volume 的 mtime 只到秒，而且容器的 stat 會快取一下：
    # 這裡把 mtime 往上推，再輪詢 memo 的 /_version 確認真的重載了，才跑 checks。
    stamp = max(time.time(), os.path.getmtime(dest) + 1)
    os.utime(dest, (stamp, stamp))
    reload_error = wait_reload(stamp)

    result = run_checks()
    good = all(v for _, v in result.get(ch, []))
    with LOCK:
        if good:
            STATE["repair"][ch] += 1
            log("修補通過 +1", f"{ch} ← {target}")
            msg = f"✓ {ch} 修補通過（功能都在、洞已封）"
        else:
            log("修補未通過", ch)
            msg = f"✗ {ch} 修補未通過（看下面的 checks）"
        if reload_error:
            msg += f"　載入失敗：{reload_error}"
    return redirect("/?msg=" + quote(msg))


@app.get("/api/state")
def api_state():
    """給講師／自己除錯看的狀態。刻意不含 flags —— 答案不放在這裡。"""
    with LOCK:
        return {"attack": STATE["attack"], "repair": STATE["repair"],
                "claimed": STATE["claimed"], "logs": STATE["logs"][:12],
                "checks": STATE["checks"]}


@app.get("/")
def index():
    msg = request.args.get("msg", "")
    with LOCK:
        flags = dict(STATE["flags"])
        atk = dict(STATE["attack"])
        rep = dict(STATE["repair"])
        checks = dict(STATE["checks"])
        logs = list(STATE["logs"][:10])
        claimed = list(STATE["claimed"])

    def attack_cell(k):
        return f"<td class=num>{atk[k]}</td>" if k in FLAGGED else '<td class="num muted">—</td>'

    def flag_cell(k):
        if k not in FLAGGED:
            return '<td><span class=muted>沒有 flag</span></td>'
        return (f"<td><code>{html.escape(flags.get(k, '—')[:16])}…</code>"
                f"{' <span class=chip ok>已交</span>' if k in claimed else ''}</td>")

    rows = "".join(
        f"<tr><td><b>{k}</b><br><span class=muted>{v}</span></td>"
        f"{attack_cell(k)}<td class=num>{rep[k]}</td>{flag_cell(k)}</tr>"
        for k, v in CHALLENGES.items())

    kinds = {"jwt": "JWT", "massassign": "Mass assignment", "ssrf": "SSRF"}
    chk_html = ""
    for key, items in checks.items():
        chips = " ".join(
            f"<span class='chip {'ok' if v else 'bad'}'>{html.escape(n)} {'pass' if v else 'fail'}</span>"
            for n, v in items)
        chk_html += f"<div class=row><b>{kinds.get(key, key)}</b>{chips}</div>"

    evs = "".join(f"<li><b>{e['t']}</b> {html.escape(e['evt'])} "
                  f"<span class=muted>{html.escape(e['detail'])}</span></li>" for e in logs)
    opts = "".join(f'<option value="{k}">{k} — {v}</option>' for k, v in CHALLENGES.items())
    opts_flagged = "".join(f'<option value="{k}">{k} — {v}</option>'
                           for k, v in CHALLENGES.items() if k in FLAGGED)

    return f"""<!doctype html><meta charset="utf-8"><title>AWDP 補丁台 · Lab B3</title>
<style>
body{{background:#0d1117;color:#e6edf3;font:15px/1.65 "PingFang TC","Microsoft JhengHei",sans-serif;margin:0;padding:28px}}
h1{{font-size:20px;margin:0 0 4px}} .muted{{color:#8b949e;font-size:13px}}
table{{width:100%;border-collapse:collapse;margin:18px 0}} td{{padding:10px 8px;border-bottom:1px solid #21262d;vertical-align:top}}
.num{{font-family:ui-monospace,monospace;font-size:18px;color:#39d353;text-align:right;width:60px}}
.grid{{display:grid;grid-template-columns:1fr 1fr;gap:16px;max-width:1200px}}
.card{{background:#161b22;border:1px solid #21262d;border-radius:8px;padding:14px}}
.card h3{{margin:0 0 8px;font-size:14px;color:#58a6ff;font-weight:600}}
input,select{{background:#0d1117;color:#e6edf3;border:1px solid #30363d;border-radius:6px;padding:8px;width:100%;box-sizing:border-box;margin:4px 0;font:inherit}}
button{{background:#238636;color:#fff;border:0;border-radius:6px;padding:9px 14px;font-weight:700;cursor:pointer;margin-top:6px}}
.chip{{display:inline-block;padding:2px 8px;border-radius:99px;font-size:12px;margin:2px}}
.chip.ok{{background:#0f3a26;color:#56d364}} .chip.bad{{background:#3d1418;color:#ff7b72}}
.msg{{margin:10px 0;color:#f0b429}} ul{{list-style:none;padding:0}} li{{padding:5px 0;border-bottom:1px solid #21262d;font-size:13px}}
.row{{padding:6px 0;border-bottom:1px solid #21262d}} .row b{{color:#8b949e;font-size:13px;margin-right:8px}}
</style>
<h1>AWDP 補丁台 · Lab B3</h1>
<div class="muted">攻破 = 交正確 flag；修補 = 上傳 handlers.py 並通過 checks。flag 每 {ROUND} 秒換一次，三條各自計分；A05 沒有 flag，只有修補。</div>
{f'<div class=msg>{html.escape(msg)}</div>' if msg else ''}
<table>{rows}</table>
<div class="grid">
  <div class="card"><h3>攻破：提交 flag</h3>
    <form method="post" action="/submit">
      <select name="challenge">{opts_flagged}</select>
      <input name="flag" placeholder="flag{{...}}" autocomplete="off">
      <button>提交</button>
    </form>
  </div>
  <div class="card"><h3>修補：上傳 handlers.py</h3>
    <form method="post" action="/apply" enctype="multipart/form-data">
      <select name="challenge">{opts}</select>
      <input name="target" value="handlers.py" placeholder="handlers.py">
      <input type="file" name="file">
      <button>upload &amp; apply</button>
    </form>
    <div class="muted">檔案會寫進 memo 的程式碼目錄，服務自己重載——不用重建容器。</div>
  </div>
  <div class="card" style="grid-column:1 / span 2"><h3>最近一次 checks</h3>
    {chk_html or '<div class=muted>還沒有 apply 過</div>'}
    <div class="muted" style="margin-top:8px">只有你選的那個洞全 pass，才算那個洞修補 +1。</div>
  </div>
  <div class="card" style="grid-column:1 / span 2"><h3>事件</h3>
    <ul>{evs or "<li class=muted>還沒有事件</li>"}</ul>
  </div>
</div>"""


if __name__ == "__main__":
    threading.Thread(target=rotate, daemon=True).start()
    app.run(host="0.0.0.0", port=8000, threaded=True)
