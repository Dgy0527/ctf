#!/bin/sh
# 第一次啟動：把種子 handlers.py 放進 /app（之後由補丁台覆寫）
if [ ! -f /app/handlers.py ]; then
  cp /seed/handlers.py /app/handlers.py
fi
exec python /app/server.py
