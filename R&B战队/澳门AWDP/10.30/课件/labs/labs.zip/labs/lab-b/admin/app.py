"""admin —— 只放在內網的內部系統，回 flag3。

沒有發佈埠：只有 compose 網路裡的 memo（經 /admin/proxy）打得到。
"""
import os

from flask import Flask

app = Flask(__name__)
FLAG_PATH = os.environ.get("FLAG_PATH", "/srv/flag3.txt")


@app.get("/health")
def health():
    return "ok"


@app.get("/ping")
def ping():
    return "pong"


@app.get("/flag")
def flag():
    try:
        with open(FLAG_PATH) as f:
            return f.read().strip()
    except OSError:
        return "no-flag"


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000, threaded=True)
