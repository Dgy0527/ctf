"""handlers.py（講師參考補丁，直接上傳到補丁台即可）

修法 1：JWT 只接受 HS256，alg=none 一律拒絕、簽章必驗。
累積式：02 含 01、03 含 01+02、04 含 01~03 —— 一次補一個洞，不會把前一個弄回去。
"""
import base64
import hashlib
import hmac
import json
import os
import re
import sqlite3
import time

import requests
from flask import redirect

SECRET = "dev"                     # JWT 的 HS256 金鑰（洞 1 的兩個弱點之一）
DB = os.environ.get("MEMO_DB", "/srv/memo.db")
DATA = os.environ.get("MEMO_DATA", "/srv")
ADMIN_URL = os.environ.get("ADMIN_URL", "http://admin:8000")
HERE = os.path.dirname(os.path.abspath(__file__))
BAK = os.path.join(HERE, "app.py.bak")      # A05：部署時忘了刪的備份檔

GIT_CONFIG = """[core]
\trepositoryformatversion = 0
\tfilemode = true
\tbare = false
[remote "origin"]
\turl = https://git.mocs.local/platform/memo.git
\tfetch = +refs/heads/*:refs/remotes/origin/*
[branch "main"]
\tremote = origin
\tmerge = refs/heads/main
"""

CSS = """
 body{font:15px/1.65 system-ui,"PingFang TC","Microsoft JhengHei",sans-serif;
      max-width:760px;margin:36px auto;padding:0 20px;color:#12203a;background:#f7f9fc}
 h1{font-size:20px;margin:0 0 6px} .muted{color:#6b7a90;font-size:13px}
 nav{margin:0 0 18px;padding-bottom:10px;border-bottom:1px solid #dbe3ee}
 nav a{margin-right:14px;color:#1a5fd0;text-decoration:none;font-size:14px}
 .card{background:#fff;border:1px solid #dbe3ee;border-radius:8px;padding:16px;margin:12px 0}
 input,textarea{width:100%;box-sizing:border-box;padding:9px;border:1px solid #cfd8e6;border-radius:6px;margin:6px 0;font:inherit}
 button{padding:9px 16px;border:0;border-radius:6px;background:#1a5fd0;color:#fff;font-weight:600;cursor:pointer}
 pre{white-space:pre-wrap;background:#0f172a;color:#e6edf3;padding:14px;border-radius:6px;margin:0}
 .msg{color:#a4262c} .ok{color:#0f7b4f}
"""

LOGIN_FORM = """<div class="card"><form method="post" action="/login">
 <input name="username" placeholder="帳號" autocomplete="off">
 <input name="password" type="password" placeholder="密碼">
 <button>登入</button></form>
 <p class="muted">示範帳號：demo / demo</p></div>"""


def page(title, body, who=None):
    nav = ('<a href="/">我的備忘錄</a><a href="/api/profile">個人資料</a>'
           '<a href="/admin/panel">管理台</a><a href="/logout">登出</a>')
    return f"""<!doctype html><meta charset="utf-8"><title>{title} · MOCS Memo</title>
<style>{CSS}</style>
<h1>{title}</h1><nav>{nav if who else '<a href="/login">登入</a>'}</nav>
{body}"""


def sha(username, password):
    return hashlib.sha256(f"{username}:{password}".encode()).hexdigest()


def db():
    conn = sqlite3.connect(DB, timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


# ---------------------------------------------------------------- JWT
def b64e(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode().rstrip("=")


def b64d(text: str) -> bytes:
    return base64.urlsafe_b64decode(text + "=" * (-len(text) % 4))


def issue(claims: dict) -> str:
    head = b64e(json.dumps({"alg": "HS256", "typ": "JWT"}).encode())
    body = b64e(json.dumps(claims).encode())
    sig = hmac.new(SECRET.encode(), f"{head}.{body}".encode(), hashlib.sha256).digest()
    return f"{head}.{body}.{b64e(sig)}"


def claims_of(req):
    """從 Authorization: Bearer 或 cookie 取 token，回傳 claims（沒有就 None）。"""
    raw = ""
    auth = req.headers.get("Authorization", "")
    if auth.lower().startswith("bearer "):
        raw = auth[7:].strip()
    if not raw:
        raw = req.cookies.get("token", "")
    if not raw:
        return None
    parts = raw.split(".")
    if len(parts) != 3:
        return None
    try:
        head = json.loads(b64d(parts[0]))
        body = json.loads(b64d(parts[1]))
    except (ValueError, json.JSONDecodeError):
        return None
    # 修法 1：演算法固定 HS256；alg=none 一律拒絕，簽章一定要驗
    if head.get("alg") != "HS256":
        return None
    sig = hmac.new(SECRET.encode(), f"{parts[0]}.{parts[1]}".encode(), hashlib.sha256).digest()
    try:
        if not hmac.compare_digest(sig, b64d(parts[2])):
            return None
    except (ValueError, TypeError):
        return None
    return body


def read_flag(name):
    try:
        with open(os.path.join(DATA, name)) as f:
            return f.read().strip()
    except OSError:
        return "no-flag-yet"


def handle(path, req):
    who = claims_of(req)
    user = (who or {}).get("sub")

    if path == "health":
        return "ok", 200

    if path == "login":
        if req.method == "POST":
            username = req.form.get("username", "").strip()
            password = req.form.get("password", "")
            row = db().execute("SELECT username, role FROM users WHERE username=? AND password=?",
                               (username, sha(username, password))).fetchone()
            if not row:
                return page("登入失敗", '<p class="msg">帳號或密碼不對。</p>' + LOGIN_FORM), 401
            token = issue({"sub": row["username"], "role": row["role"], "iat": int(time.time())})
            resp = redirect("/")
            resp.set_cookie("token", token, httponly=True)
            resp.headers["X-Token"] = token          # 方便 curl 拿 token
            return resp
        return page("登入", LOGIN_FORM), 200

    if path == "logout":
        resp = redirect("/login")
        resp.delete_cookie("token")
        return resp

    if path == "":
        if not user:
            return redirect("/login")
        conn = db()
        rows = conn.execute("SELECT id, title, body FROM memos WHERE owner=? ORDER BY id",
                            (user,)).fetchall()
        conn.close()
        items = "".join(
            f'<div class="card"><b>#{r["id"]} {r["title"]}</b>'
            f'<p class="muted">{r["body"][:120]}</p><a href="/memo/{r["id"]}">打開</a></div>'
            for r in rows) or '<p class="muted">還沒有備忘錄</p>'
        return page("我的備忘錄", items, user), 200

    m = re.fullmatch(r"memo/(\d+)", path)
    if m:
        if not user:
            return redirect("/login")
        conn = db()
        row = conn.execute("SELECT id, owner, title, body FROM memos WHERE id=?",
                           (int(m.group(1)),)).fetchone()
        conn.close()
        if not row or row["owner"] != user:
            return page("找不到", '<p class="muted">沒有這則備忘錄。</p>', user), 404
        body = (f'<div class="card"><b>{row["title"]}</b>'
                f'<p class="muted">作者：{row["owner"]}</p><pre>{row["body"]}</pre></div>')
        return page(f'備忘錄 #{row["id"]}', body, user), 200

    if path == "api/profile":
        if not user:
            return {"error": "unauthorized"}, 401
        conn = db()
        if req.method == "GET":
            row = conn.execute("SELECT username, role, bio, email FROM users WHERE username=?",
                               (user,)).fetchone()
            conn.close()
            if not row:
                return {"error": "no such user"}, 404
            return json.dumps(dict(row), ensure_ascii=False), 200, {"Content-Type": "application/json"}
        if req.method == "PATCH":
            # 洞 2：body 的 key 全部當成欄位寫進 users —— 包括 role
            data = req.get_json(silent=True)
            if not isinstance(data, dict) or not data:
                return {"error": "send a JSON object"}, 400
            sets = ", ".join(f"{k}=?" for k in data)
            try:
                conn.execute(f"UPDATE users SET {sets} WHERE username=?", (*data.values(), user))
                conn.commit()
            except sqlite3.Error as exc:
                conn.close()
                return {"error": f"db: {exc}"}, 400
            row = conn.execute("SELECT username, role, bio, email FROM users WHERE username=?",
                               (user,)).fetchone()
            conn.close()
            return json.dumps(dict(row), ensure_ascii=False), 200, {"Content-Type": "application/json"}
        conn.close()
        return {"error": "method not allowed"}, 405

    if path == "admin/panel":
        if not user:
            return redirect("/login")
        conn = db()
        row = conn.execute("SELECT role FROM users WHERE username=?", (user,)).fetchone()
        conn.close()
        blocks = []
        # 身分區：只看 token 裡說了什麼（洞 1 打這裡）
        if (who or {}).get("role") == "admin":
            blocks.append(f'<div class="card"><b>身分區（來自 JWT）</b><pre>{read_flag("flag1.txt")}</pre></div>')
        else:
            blocks.append('<div class="card"><b>身分區（來自 JWT）</b>'
                          f'<p class="muted">token 說你是 role={(who or {}).get("role")}</p></div>')
        # 帳號區：只看資料庫裡的 role（洞 2 打這裡）
        if row and row["role"] == "admin":
            blocks.append(f'<div class="card"><b>帳號區（來自 DB）</b><pre>{read_flag("flag2.txt")}</pre></div>')
        else:
            blocks.append('<div class="card"><b>帳號區（來自 DB）</b>'
                          f'<p class="muted">帳號角色是 {(row["role"] if row else "不存在")}</p></div>')
        return page("管理台", "".join(blocks), user), 200

    if path == "app.py.bak":
        # A05：備份檔忘了刪 —— 裡面有 SECRET 和所有洞的邏輯
        try:
            with open(BAK) as f:
                return f.read(), 200, {"Content-Type": "text/plain; charset=utf-8"}
        except OSError:
            return "not found", 404

    if path == ".git/config":
        # A05：.git 沒刪，遠端網址與分支設定直接露出來
        return GIT_CONFIG, 200, {"Content-Type": "text/plain; charset=utf-8"}

    if path == "fetch":
        # 洞 3：url 原樣送出去，沒有白名單
        url = req.args.get("url", "").strip()
        if not url:
            return "missing url", 400
        try:
            r = requests.get(url, timeout=5)
        except requests.RequestException as exc:
            return f"fetch failed: {exc}", 502
        return r.text, 200

    return "not found", 404
