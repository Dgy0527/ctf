"""server.py —— 載入 /app/handlers.py，檔案一變就重載（補丁台上傳後不用重啟）。

帳號、備忘錄、私人備註這些「環境」在這裡建；
洞與路由在 handlers.py —— 那才是學生要改、補丁台會替換的那個檔。
"""
import hashlib
import importlib.util
import os
import secrets
import sqlite3

from flask import Flask, request

APP_DIR = os.environ.get("APP_DIR", "/app")
DB = os.environ.get("MEMO_DB", "/srv/memo.db")
MOD_PATH = os.path.join(APP_DIR, "handlers.py")

app = Flask(__name__)
_state = {"mtime": 0.0, "mod": None}


def sha(username: str, password: str) -> str:
    return hashlib.sha256(f"{username}:{password}".encode()).hexdigest()


def db():
    conn = sqlite3.connect(DB, timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


def init() -> None:
    os.makedirs(os.path.dirname(DB) or ".", exist_ok=True)
    conn = db()
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS users(
            username TEXT PRIMARY KEY,
            password TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'user',
            bio TEXT NOT NULL DEFAULT '',
            email TEXT NOT NULL DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS memos(
            id INTEGER PRIMARY KEY,
            owner TEXT NOT NULL,
            title TEXT NOT NULL DEFAULT '',
            body TEXT NOT NULL
        );
        """
    )
    conn.execute("INSERT OR IGNORE INTO users(username, password, role, bio, email) VALUES(?,?,?,?,?)",
                 ("demo", sha("demo", "demo"), "user", "實習生，負責備忘錄。", "demo@mocs.local"))
    # admin 的密碼是隨機的：每一輪由補丁台換掉，學生不會知道（要當 admin 只能走兩個洞）
    # admin 這個帳號的 role 是 user：它只是「平台代管的帳號」，不是管理員。
    # 管理身分只能靠 JWT 的 role claim（洞 1）或把自己的帳號升級（洞 2）拿到。
    conn.execute("INSERT OR IGNORE INTO users(username, password, role, bio, email) VALUES(?,?,?,?,?)",
                 ("admin", sha("admin", secrets.token_hex(16)), "user", "平台代管帳號。", "admin@mocs.local"))
    conn.execute("UPDATE users SET role='user' WHERE username='admin'")
    conn.execute("INSERT OR IGNORE INTO memos(id, owner, title, body) VALUES(?,?,?,?)",
                 (1, "demo", "購物清單", "牛奶、蛋、咖啡豆。"))
    conn.execute("INSERT OR IGNORE INTO memos(id, owner, title, body) VALUES(?,?,?,?)",
                 (2, "demo", "交接事項", "週五前把 Q3 的資料歸檔。"))
    conn.commit()
    conn.close()


def handler():
    mtime = os.path.getmtime(MOD_PATH)
    if mtime != _state["mtime"]:
        spec = importlib.util.spec_from_file_location("handlers", MOD_PATH)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        _state["mod"] = mod
        _state["mtime"] = mtime
    return _state["mod"]


@app.get("/_version")
def version():
    """補丁有沒有生效看這裡：loaded = 目前載入的 handlers.py 的 mtime。"""
    err = ""
    try:
        handler()               # 觸發重載檢查
    except Exception as exc:
        err = f"{type(exc).__name__}: {exc}"
    return {"loaded": _state["mtime"], "file": os.path.getmtime(MOD_PATH), "error": err}


@app.route("/", defaults={"path": ""}, methods=["GET", "POST", "PATCH", "PUT", "DELETE"])
@app.route("/<path:path>", methods=["GET", "POST", "PATCH", "PUT", "DELETE"])
def dispatch(path):
    mod = handler()
    try:
        return mod.handle(path, request)
    except Exception as exc:      # 讓 500 帶原因，方便教學
        return f"error: {exc}", 500


init()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000, threaded=True)
