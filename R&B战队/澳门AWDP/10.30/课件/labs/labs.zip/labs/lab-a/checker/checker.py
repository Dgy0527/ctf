"""checker —— 每輪做三件事：換 flag（三條）、驗功能、報分。

驗的三個功能，就是你不能改壞的東西：
  1. /health 回 ok
  2. 用 demo/demo 登入會成功
  3. /download?file=welcome.txt 還能下載

把路徑穿越補掉、但這三個還過 → 防禦分照拿。
把 /download 整個關掉 → 第 3 項紅，這一輪 0 分。這就是 SLA。

三條 flag 各自對應一個洞（洞補了，bot 就偷不到那條）：
  flag1.txt ← /download 路徑穿越
  flag2.txt ← /hello 模板注入
  flag3.txt ← /login SQL 注入 → /admin
"""
import os
import secrets
import time

import requests

ROUND = int(os.environ.get("ROUND_SECONDS", "60"))
BOARD = os.environ["BOARD"].rstrip("/")
TARGETS = {"A": os.environ["TARGET_A"].rstrip("/"), "B": os.environ["TARGET_B"].rstrip("/")}
DATA = {"A": os.environ["DATA_A"], "B": os.environ["DATA_B"]}
TOKEN = os.environ.get("BOARD_TOKEN", "").strip()
HEADERS = {"X-Board-Token": TOKEN}

FLAG_KEYS = ("flag1", "flag2", "flag3")


def plant(team: str) -> dict:
    """三條 flag 寫進該隊的資料目錄；回傳 {"flag1": …, "flag2": …, "flag3": …}。"""
    flags = {}
    for key in FLAG_KEYS:
        value = "flag{%s}" % secrets.token_hex(10)
        with open(os.path.join(DATA[team], key + ".txt"), "w", encoding="utf-8") as f:
            f.write(value + "\n")
        flags[key] = value
    return flags


def check(base: str) -> dict:
    """回傳每個功能點的結果；全部 True 才算這一輪活著。"""
    out = {}
    try:
        r = requests.get(base + "/health", timeout=3)
        out["health"] = r.status_code == 200 and r.text.strip() == "ok"
    except Exception as exc:
        out["health"] = False
        out["_error"] = str(exc)
        return out

    try:
        r = requests.post(base + "/login", data={"username": "demo", "password": "demo"},
                          timeout=3, allow_redirects=False)
        out["login"] = r.status_code in (301, 302, 303)
    except Exception:
        out["login"] = False

    try:
        r = requests.get(base + "/download", params={"file": "welcome.txt"}, timeout=3)
        out["download"] = r.status_code == 200 and "welcome" in r.text
    except Exception:
        out["download"] = False
    return out


def resume_round() -> int:
    """記分板可能還留著上一輪的狀態（board_data volume）：接著它的輪次往下報。"""
    try:
        r = requests.get(BOARD + "/api/state", timeout=3)
        return int(r.json().get("round", 0))
    except Exception:
        return 0


def main() -> None:
    rnd = resume_round()
    while True:
        rnd += 1
        reports = {}
        for team, base in TARGETS.items():
            try:
                flags = plant(team)
                planted = True
            except Exception as exc:
                planted = False
                flags = {}
                print(f"[checker] plant {team} failed: {exc}", flush=True)

            checks = check(base)
            ok = planted and all(v for k, v in checks.items() if not k.startswith("_"))
            reports[team] = {"round": rnd, "team": team, "sla_ok": ok,
                             "checks": checks, "flags": flags}
            shown = " ".join("%s=%s" % (k, (v[:12] + "…") if v else "-") for k, v in flags.items())
            print(f"[checker] round {rnd} team {team} ok={ok} {checks} {shown}", flush=True)

        try:
            r = requests.post(BOARD + "/api/round", json=reports, headers=HEADERS, timeout=5)
            if r.status_code != 200:
                print(f"[checker] board rejected: {r.status_code} {r.text[:120]}", flush=True)
        except Exception as exc:
            print(f"[checker] board unreachable: {exc}", flush=True)

        time.sleep(ROUND)


if __name__ == "__main__":
    main()
