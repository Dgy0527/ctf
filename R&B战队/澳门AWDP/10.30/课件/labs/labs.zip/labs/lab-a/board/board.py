"""board —— 記分板與提交口。

分數規則（跟真比賽同構，只是數字縮小）：
  防禦分  +10／輪　checker 三個功能全過才給
  被偷分  -10　　  你的一條 flag 被 bot 讀走（同一條每輪只扣一次）
  攻擊分  +15　　  你提交對手的一條 flag（三條各算一次，滿分 45）

三條 flag 對應三個洞：flag1 路徑穿越、flag2 模板注入、flag3 SQL 注入 → /admin。
攻擊挑一條就夠，防守要三條都補。
"""
import hmac
import json
import os
import threading
import time

from flask import Flask, request, jsonify, redirect

app = Flask(__name__)

DEF_POINTS = 10
STEAL_POINTS = 10
ATTACK_POINTS = 15
ROUND_SECONDS = int(os.environ.get("ROUND_SECONDS", "60"))
FLAG_KEYS = ("flag1", "flag2", "flag3")

STATE_PATH = os.environ.get("STATE_PATH", "")
# checker／bot 打 /api/round、/api/steal 要帶這個（compose 三個服務同時設定）
BOARD_TOKEN = os.environ.get("BOARD_TOKEN", "").strip()

LOCK = threading.Lock()
STATE = {
    "round": 0,
    "started": time.time(),
    "scores": {"A": 0, "bot": 0, "player": 0},
    "flags": {"A": {}, "B": {}},      # {"A": {"flag1": …, "flag2": …, "flag3": …}, "B": {…}}
    "consumed": [],                   # 本輪已計分的對手 flag（同一條只算一次）
    "stolen": [],                     # 本輪已被 bot 偷走的自己的 flag
    "sla": {"A": None, "B": None},
    "checks": {"A": {}, "B": {}},
    "events": [],
    "message": "",
}


def save() -> None:
    if not STATE_PATH:
        return
    try:
        with open(STATE_PATH, "w", encoding="utf-8") as f:
            json.dump(STATE, f)
    except OSError:
        pass


def load() -> None:
    if not STATE_PATH or not os.path.exists(STATE_PATH):
        return
    try:
        with open(STATE_PATH, encoding="utf-8") as f:
            STATE.update(json.load(f))
    except (OSError, ValueError):
        pass
    # 舊版存下來的 flags 是字串，這裡統一成 dict，免得老 state 檔把記分板弄壞
    for team in ("A", "B"):
        if not isinstance(STATE["flags"].get(team), dict):
            STATE["flags"][team] = {}


def authed() -> bool:
    """只有知道 BOARD_TOKEN 的服務（checker／bot）能改分數。沒設 token 就一律拒絕。"""
    if not BOARD_TOKEN:
        return False
    got = request.headers.get("X-Board-Token") or request.args.get("token", "")
    return hmac.compare_digest(got, BOARD_TOKEN)


def log(evt: str, detail: str = "") -> None:
    STATE["events"].insert(0, {"t": time.strftime("%H:%M:%S"), "evt": evt, "detail": detail})
    del STATE["events"][40:]


@app.post("/api/round")
def api_round():
    if not authed():
        return jsonify(ok=False, why="缺少或錯誤的 X-Board-Token"), 403
    reports = request.get_json(silent=True)
    if not isinstance(reports, dict) or not reports:
        return jsonify(ok=False, why="body 要是 JSON 物件"), 400

    rounds = []
    for team, rep in reports.items():
        if team not in ("A", "B"):
            continue
        if not isinstance(rep, dict):
            return jsonify(ok=False, why="%s 的內容不是物件" % team), 400
        raw = rep.get("round")
        if isinstance(raw, bool) or not isinstance(raw, int):
            return jsonify(ok=False, why="%s.round 要是整數" % team), 400
        if not isinstance(rep.get("flags", {}), dict):
            return jsonify(ok=False, why="%s.flags 要是物件" % team), 400
        rounds.append(raw)
    if not rounds:
        return jsonify(ok=False, why="沒有 A/B 的報告"), 400

    new_round = max(rounds)
    with LOCK:
        lo, hi = STATE["round"], STATE["round"] + 1
        if new_round < lo or new_round > hi:
            return jsonify(ok=False, why="round 只能是 %d 或 %d" % (lo, hi)), 400
        if new_round > STATE["round"]:
            STATE["round"] = new_round
            STATE["consumed"] = []      # 新的一輪：三條重新可交、可被偷
            STATE["stolen"] = []

        for team, rep in reports.items():
            if team not in ("A", "B"):
                continue
            flags = rep.get("flags") or {}
            STATE["flags"][team] = flags if isinstance(flags, dict) else {}
            STATE["sla"][team] = bool(rep.get("sla_ok"))
            STATE["checks"][team] = rep.get("checks", {})
            if team == "A" and rep.get("sla_ok"):
                STATE["scores"]["A"] += DEF_POINTS
                log("防禦分 +%d" % DEF_POINTS, "第 %s 輪 SLA 通過" % rep.get("round"))
            elif team == "A":
                log("SLA 失敗", "第 %s 輪不計分" % rep.get("round"))
        save()
    return jsonify(ok=True)


@app.post("/api/steal")
def api_steal():
    if not authed():
        return jsonify(ok=False, why="缺少或錯誤的 X-Board-Token"), 403
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return jsonify(ok=False, why="body 要是 JSON 物件"), 400
    flag = (data.get("flag") or "").strip()
    by = data.get("by", "bot")
    with LOCK:
        if by != "bot":
            return jsonify(ok=False, why="unknown actor"), 400
        mine = STATE["flags"].get("A") or {}
        key = next((k for k, v in mine.items() if v and v == flag), None)
        if not key:
            return jsonify(ok=False, why="flag 不是目前的"), 400
        if key in STATE["stolen"]:
            return jsonify(ok=False, why="%s 本輪已經偷過" % key), 400
        STATE["stolen"].append(key)
        STATE["scores"]["A"] -= STEAL_POINTS
        STATE["scores"]["bot"] += STEAL_POINTS
        log("你的 flag 被偷", "%s　bot +%d / 你 -%d" % (key, STEAL_POINTS, STEAL_POINTS))
        save()
        return jsonify(ok=True)


@app.post("/submit")
def submit():
    flag = (request.form.get("flag") or "").strip()
    with LOCK:
        theirs = STATE["flags"].get("B") or {}
        mine = STATE["flags"].get("A") or {}
        key = next((k for k, v in theirs.items() if v and v == flag), None)
        is_mine = any(v and v == flag for v in mine.values())

        if not flag:
            STATE["message"] = "空的。flag 長得像 flag{...}"
        elif key and key in STATE["consumed"]:
            STATE["message"] = "這條（%s）本輪已經交過了，還有另外兩條。" % key
            log("重複提交", key)
        elif key:
            STATE["consumed"].append(key)
            STATE["scores"]["player"] += ATTACK_POINTS
            STATE["message"] = "✓ 正確，%s +%d 分（本輪已交 %d/3）" % (
                key, ATTACK_POINTS, len(STATE["consumed"]))
            log("攻擊分 +%d" % ATTACK_POINTS, "交了對手的 %s" % key)
        elif is_mine:
            STATE["message"] = "那是你自己的 flag，不算分。要打 target-b（8002）。"
            log("無效提交", "拿自己的 flag 來交")
        else:
            STATE["message"] = "✗ 不對，或已經過期。flag 每輪更換，看到就要馬上交。"
            log("無效提交", "過期或不存在的 flag")
        save()
    return redirect("/")


@app.get("/api/state")
def api_state():
    """對外的狀態：不含 flags —— 答案不進 API（首頁照樣顯示遮罩後的資訊）。"""
    with LOCK:
        return jsonify({k: v for k, v in STATE.items() if k != "flags"})


@app.get("/")
def index():
    with LOCK:
        s = dict(STATE)
        s["events"] = list(STATE["events"][:12])
    rows = "".join(
        "<tr><td>%s</td><td>%s</td></tr>" % (k, v)
        for k, v in (("你（target-a）", s["scores"]["A"]),
                     ("bot", s["scores"]["bot"]),
                     ("你的攻擊分", s["scores"]["player"]))
    )
    checks = "".join(
        "<span class='chip %s'>%s %s</span>" % ("ok" if v else "bad", k, "過" if v else "掛")
        for k, v in s["checks"]["A"].items() if not k.startswith("_")
    )
    consumed = s["consumed"]
    bflags = [k for k in FLAG_KEYS if (s["flags"].get("B") or {}).get(k)]
    have = "".join(
        "<span class='chip %s'>%s %s</span>" % (
            "ok" if k in consumed else ("bad" if k in bflags else ""),
            k, "已交" if k in consumed else ("未交" if k in bflags else "—"))
        for k in FLAG_KEYS
    ) if bflags else "<span class='muted'>等第一輪</span>"
    events = "".join(
        "<li><b>%s</b> %s <span class='muted'>%s</span></li>" % (e["t"], e["evt"], e["detail"])
        for e in s["events"]
    )
    return f"""<!doctype html><meta charset="utf-8">
<title>Lab A · 記分板</title>
<style>
 body{{background:#0b1220;color:#e8eff8;font:14px/1.6 system-ui,"PingFang TC","Microsoft JhengHei",sans-serif;margin:0;padding:32px}}
 h1{{font-size:22px;margin:0 0 4px}} .sub{{color:#8fa3bd;margin-bottom:24px}}
 .grid{{display:grid;grid-template-columns:1fr 1fr;gap:20px;max-width:980px}}
 .card{{background:#15243c;border:1px solid #22375a;border-radius:10px;padding:18px}}
 table{{width:100%;border-collapse:collapse}} td{{padding:6px 0;border-bottom:1px solid #1e3352}}
 td:last-child{{text-align:right;font-weight:700;font-variant-numeric:tabular-nums}}
 .chip{{display:inline-block;background:#1e3352;border-radius:999px;padding:2px 10px;margin:4px 6px 0 0;font-size:12px}}
 .chip.ok{{background:#0e3a2a;color:#7ee2b8}} .chip.bad{{background:#3a1016;color:#ff9aa8}}
 input{{width:100%;padding:10px;border-radius:8px;border:1px solid #22375a;background:#0b1220;color:#e8eff8;font-size:13px}}
 button{{margin-top:8px;padding:10px 18px;border-radius:8px;border:0;background:#0b5fbe;color:#fff;font-weight:700;cursor:pointer}}
 ul{{list-style:none;padding:0;margin:8px 0 0}} li{{padding:6px 0;border-bottom:1px solid #1e3352;font-size:13px}}
 .muted{{color:#8fa3bd}} .msg{{margin-top:10px;color:#ffd479;min-height:20px}}
</style>
<h1>Lab A · 記分板</h1>
<div class="sub">第 <b id="rnd">{s["round"]}</b> 輪　·　每輪 {ROUND_SECONDS} 秒　·　你打 <b>localhost:8002</b>，bot 打 <b>localhost:8001</b></div>
<div class="grid">
  <div class="card">
    <table>{rows}</table>
    <div style="margin-top:12px"><b>本輪 SLA</b><br>{checks or "<span class='muted'>等第一輪</span>"}</div>
  </div>
  <div class="card">
    <b>提交 flag</b>　<span class="muted">本輪已交 <b>{len(consumed)}/3</b></span>
    <div>{have}</div>
    <form method="post" action="/submit">
      <input name="flag" placeholder="flag{...}" autocomplete="off">
      <button>提交</button>
    </form>
    <div class="msg">{s["message"]}</div>
  </div>
  <div class="card" style="grid-column:1 / span 2">
    <b>事件</b><ul>{events or "<li class='muted'>還沒有事件</li>"}</ul>
  </div>
</div>
<script>
async function tick(){{
  const r = await fetch('/api/state'); const s = await r.json();
  document.getElementById('rnd').textContent = s.round;
  setTimeout(tick, 3000);
}}
setTimeout(tick, 3000);
</script>"""


load()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000, threaded=True)
