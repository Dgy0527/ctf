/*
 * EchoVault — a tiny echo service with a hidden vault.
 *
 * The vault routine below is never called by the normal flow. It is the
 * ret2win target: overflow the 64-byte message buffer in echo() and overwrite
 * the saved return address with &vault.
 *
 * Build (must match the Dockerfile / patch attachment):
 *   gcc -O0 -fno-stack-protector -fno-omit-frame-pointer \
 *       -fcf-protection=none -no-pie -Wno-stringop-overflow -o pwn pwn.c
 */
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#ifndef FLAG_PATH
#define FLAG_PATH "/home/pwn/flag"
#endif

/* Never reached by the normal flow. This is the ret2win target. */
__attribute__((used)) static void vault(void)
{
    char flag[128];
    int fd = open(FLAG_PATH, O_RDONLY);

    if (fd < 0) {
        write(STDOUT_FILENO, "Vault unavailable.\n", 19);
        _exit(1);
    }

    ssize_t n = read(fd, flag, sizeof(flag) - 1);
    if (n > 0) {
        flag[n] = '\0';
        write(STDOUT_FILENO, "VAULT ", 6);
        write(STDOUT_FILENO, flag, (size_t)n);
    }
    close(fd);
    _exit(0);
}

static void echo(void)
{
    char message[64];

    fputs("Message: ", stdout);
    if (!fgets(message, 512, stdin))  
        return;
    message[strcspn(message, "\n")] = '\0';
    printf("%s\n", message);
    fflush(stdout);
}

int main(void)
{
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    alarm(60);
    echo();
    return 0;
}
